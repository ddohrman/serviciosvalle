import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc,
  updateDoc,
  increment,
  getDocs, 
  onSnapshot, 
  writeBatch
} from 'firebase/firestore';
import { AppAdvertisement, Professional, ProAccount, AppAnalytics } from '../types';
import { DEFAULT_ADVERTISEMENTS, INITIAL_PROFESSIONALS, INITIAL_ACCOUNTS } from '../data/mockData';
import firebaseConfigRaw from '../../firebase-applet-config.json';

export const firebaseConfig = firebaseConfigRaw;

// Initialize Firebase App
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Firestore with specific databaseId if provided
export const db = firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

const ADS_COLLECTION = 'advertisements';
const PROS_COLLECTION = 'professionals';
const ACCOUNTS_COLLECTION = 'proAccounts';

// Flag to track whether initial seeding has been executed in this session
let isSeeding = false;

/**
 * Seeds initial mock data into Firestore if collections are empty.
 */
export async function seedFirestoreIfEmpty(): Promise<void> {
  if (isSeeding) return;
  isSeeding = true;

  try {
    // 1. Check advertisements
    const adsSnapshot = await getDocs(collection(db, ADS_COLLECTION));
    if (adsSnapshot.empty) {
      console.log('Seeding initial advertisements to Firestore...');
      const batch = writeBatch(db);
      for (const ad of DEFAULT_ADVERTISEMENTS) {
        const adRef = doc(db, ADS_COLLECTION, ad.id);
        batch.set(adRef, { ...ad, updatedAt: new Date().toISOString() });
      }
      await batch.commit();
      console.log('Advertisements seeded successfully.');
    }

    // 2. Check professionals
    const prosSnapshot = await getDocs(collection(db, PROS_COLLECTION));
    if (prosSnapshot.empty) {
      console.log('Seeding initial professionals to Firestore...');
      const batch = writeBatch(db);
      for (const pro of INITIAL_PROFESSIONALS) {
        const proRef = doc(db, PROS_COLLECTION, pro.id);
        batch.set(proRef, pro);
      }
      await batch.commit();
      console.log('Professionals seeded successfully.');
    }

    // 3. Check pro accounts
    const accSnapshot = await getDocs(collection(db, ACCOUNTS_COLLECTION));
    if (accSnapshot.empty) {
      console.log('Seeding initial pro accounts to Firestore...');
      const batch = writeBatch(db);
      for (const acc of INITIAL_ACCOUNTS) {
        const accRef = doc(db, ACCOUNTS_COLLECTION, acc.id);
        batch.set(accRef, acc);
      }
      await batch.commit();
      console.log('Pro accounts seeded successfully.');
    }
  } catch (error) {
    console.warn('Firebase seeding notice (safe to ignore if offline or during setup):', error);
  } finally {
    isSeeding = false;
  }
}

/**
 * Real-time listener for Advertisements
 */
export function subscribeToAdvertisements(
  callback: (ads: AppAdvertisement[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const adsRef = collection(db, ADS_COLLECTION);
    const unsubscribe = onSnapshot(adsRef, (snapshot) => {
      if (!snapshot.empty) {
        const ads: AppAdvertisement[] = [];
        snapshot.forEach(docSnap => {
          ads.push({ id: docSnap.id, ...docSnap.data() } as AppAdvertisement);
        });
        callback(ads);
      } else {
        // If empty on remote, trigger seeding
        seedFirestoreIfEmpty();
      }
    }, (err) => {
      console.warn('Advertisements listener warning:', err);
      if (onError) onError(err);
    });

    return unsubscribe;
  } catch (err) {
    console.error('Failed to subscribe to advertisements:', err);
    return () => {};
  }
}

/**
 * Save advertisements list to Firestore (syncs to all devices)
 */
export async function saveAdvertisementsToFirestore(ads: AppAdvertisement[]): Promise<void> {
  try {
    const batch = writeBatch(db);
    for (const ad of ads) {
      const adRef = doc(db, ADS_COLLECTION, ad.id);
      batch.set(adRef, { ...ad, updatedAt: new Date().toISOString() }, { merge: true });
    }
    await batch.commit();
  } catch (err) {
    console.error('Error saving advertisements to Firestore:', err);
    throw err;
  }
}

/**
 * Real-time listener for Professionals
 */
export function subscribeToProfessionals(
  callback: (pros: Professional[]) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const prosRef = collection(db, PROS_COLLECTION);
    const unsubscribe = onSnapshot(prosRef, (snapshot) => {
      if (!snapshot.empty) {
        const pros: Professional[] = [];
        snapshot.forEach(docSnap => {
          pros.push({ id: docSnap.id, ...docSnap.data() } as Professional);
        });
        callback(pros);
      } else {
        seedFirestoreIfEmpty();
      }
    }, (err) => {
      console.warn('Professionals listener warning:', err);
      if (onError) onError(err);
    });

    return unsubscribe;
  } catch (err) {
    console.error('Failed to subscribe to professionals:', err);
    return () => {};
  }
}

/**
 * Save or update a single professional (registration or approval)
 */
export async function saveProfessionalToFirestore(pro: Professional): Promise<void> {
  try {
    const proRef = doc(db, PROS_COLLECTION, pro.id);
    await setDoc(proRef, pro, { merge: true });
  } catch (err) {
    console.error('Error saving professional to Firestore:', err);
    throw err;
  }
}

/**
 * Save multiple professionals (e.g. bulk approval)
 */
export async function saveProfessionalsBatchToFirestore(pros: Professional[]): Promise<void> {
  try {
    const batch = writeBatch(db);
    for (const pro of pros) {
      const proRef = doc(db, PROS_COLLECTION, pro.id);
      batch.set(proRef, pro, { merge: true });
    }
    await batch.commit();
  } catch (err) {
    console.error('Error saving professionals batch to Firestore:', err);
    throw err;
  }
}

/**
 * Real-time listener for Pro Accounts
 */
export function subscribeToProAccounts(
  callback: (accounts: ProAccount[]) => void
): () => void {
  try {
    const accRef = collection(db, ACCOUNTS_COLLECTION);
    const unsubscribe = onSnapshot(accRef, (snapshot) => {
      if (!snapshot.empty) {
        const accounts: ProAccount[] = [];
        snapshot.forEach(docSnap => {
          accounts.push({ id: docSnap.id, ...docSnap.data() } as ProAccount);
        });
        callback(accounts);
      }
    }, (err) => {
      console.warn('Pro accounts listener warning:', err);
    });

    return unsubscribe;
  } catch (err) {
    console.error('Failed to subscribe to pro accounts:', err);
    return () => {};
  }
}

/**
 * Save a new pro account (username / password / subscription status)
 */
export async function saveProAccountToFirestore(account: ProAccount): Promise<void> {
  try {
    const accRef = doc(db, ACCOUNTS_COLLECTION, account.id);
    await setDoc(accRef, account, { merge: true });
  } catch (err) {
    console.error('Error saving pro account to Firestore:', err);
    throw err;
  }
}

const ANALYTICS_COLLECTION = 'analytics';
const STATS_DOC_ID = 'general';

export const DEFAULT_ANALYTICS: AppAnalytics = {
  id: STATS_DOC_ID,
  totalClientVisits: 142,
  uniqueClientsCount: 89,
  totalWhatsAppContacts: 64,
  totalRequestsCreated: 18,
  lastClientVisitAt: new Date().toISOString(),
  firstRecordedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
};

/**
 * Real-time listener for general App Analytics
 */
export function subscribeToAnalytics(
  callback: (analytics: AppAnalytics) => void,
  onError?: (err: Error) => void
): () => void {
  try {
    const statsDocRef = doc(db, ANALYTICS_COLLECTION, STATS_DOC_ID);
    const unsubscribe = onSnapshot(statsDocRef, (docSnap) => {
      if (docSnap.exists()) {
        callback({ id: docSnap.id, ...docSnap.data() } as AppAnalytics);
      } else {
        // Initialize default stats document if not exists
        setDoc(statsDocRef, DEFAULT_ANALYTICS).catch(() => {});
        callback(DEFAULT_ANALYTICS);
      }
    }, (err) => {
      console.warn('Analytics listener warning:', err);
      if (onError) onError(err);
    });

    return unsubscribe;
  } catch (err) {
    console.error('Failed to subscribe to analytics:', err);
    return () => {};
  }
}

/**
 * Record a client/neighbor visit session and track unique client
 */
export async function recordClientAppUsage(): Promise<void> {
  if (typeof window === 'undefined') return;
  try {
    const statsDocRef = doc(db, ANALYTICS_COLLECTION, STATS_DOC_ID);
    
    // Check unique client
    let isNewClient = false;
    let clientId = localStorage.getItem('oficios_client_id');
    if (!clientId) {
      clientId = 'cli_' + Math.random().toString(36).substring(2, 9) + '_' + Date.now();
      localStorage.setItem('oficios_client_id', clientId);
      isNewClient = true;
    }

    // Throttle session count (1 session recorded per 15 minutes per device)
    const lastSession = localStorage.getItem('oficios_last_session');
    const now = Date.now();
    const shouldCountSession = !lastSession || (now - parseInt(lastSession, 10) > 15 * 60 * 1000);

    if (shouldCountSession) {
      localStorage.setItem('oficios_last_session', now.toString());
      
      const snap = await getDoc(statsDocRef);
      if (!snap.exists()) {
        await setDoc(statsDocRef, {
          ...DEFAULT_ANALYTICS,
          totalClientVisits: DEFAULT_ANALYTICS.totalClientVisits + 1,
          uniqueClientsCount: DEFAULT_ANALYTICS.uniqueClientsCount + (isNewClient ? 1 : 0),
          lastClientVisitAt: new Date().toISOString()
        });
      } else {
        await updateDoc(statsDocRef, {
          totalClientVisits: increment(1),
          ...(isNewClient ? { uniqueClientsCount: increment(1) } : {}),
          lastClientVisitAt: new Date().toISOString()
        });
      }
    }
  } catch (err) {
    console.warn('Analytics recording notice (safe to ignore if offline):', err);
  }
}

/**
 * Record a WhatsApp contact action by a client to a professional
 */
export async function recordWhatsAppContact(): Promise<void> {
  try {
    const statsDocRef = doc(db, ANALYTICS_COLLECTION, STATS_DOC_ID);
    const snap = await getDoc(statsDocRef);
    if (!snap.exists()) {
      await setDoc(statsDocRef, {
        ...DEFAULT_ANALYTICS,
        totalWhatsAppContacts: DEFAULT_ANALYTICS.totalWhatsAppContacts + 1
      });
    } else {
      await updateDoc(statsDocRef, {
        totalWhatsAppContacts: increment(1)
      });
    }
  } catch (err) {
    console.warn('Analytics WhatsApp click notice:', err);
  }
}

/**
 * Record when a client creates a new service request / pedido de presupuesto
 */
export async function recordServiceRequestCreated(): Promise<void> {
  try {
    const statsDocRef = doc(db, ANALYTICS_COLLECTION, STATS_DOC_ID);
    const snap = await getDoc(statsDocRef);
    if (!snap.exists()) {
      await setDoc(statsDocRef, {
        ...DEFAULT_ANALYTICS,
        totalRequestsCreated: DEFAULT_ANALYTICS.totalRequestsCreated + 1
      });
    } else {
      await updateDoc(statsDocRef, {
        totalRequestsCreated: increment(1)
      });
    }
  } catch (err) {
    console.warn('Analytics request created notice:', err);
  }
}

