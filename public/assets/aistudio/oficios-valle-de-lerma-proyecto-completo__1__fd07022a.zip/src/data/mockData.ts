import { Professional, ServiceCategory, Neighborhood, ServiceRequest, UserProfile, AppAdvertisement, ProAccount } from '../types';

export const APP_LOGO_URL = '/logo-valle-lerma.jpg';

export const USER_AVATAR_URL = 'https://lh3.googleusercontent.com/aida-public/AB6AXuCkRyDruTTB2Ap6-tdRMRNBBsfRfffrD9PzPM9nYoSZjSO7arSpCby1IxyRPYfm9hPjhFz_2RX5vIEBd5mPo-mRXydQQJsvaImlANPoXNAo-59qM6VCeeeSeAgaexoV18D4ionmZ4d9yexIV1O7zARVBf3CkpCPGjimn817yZ1VCrLGudS7X2KmUQqJ_Tpds3EhGf_hQB75tkFWy0JwJZ_vk_0-z4HA4mjUfhM1c8W7m2wXo0EqeVad';

export const NEIGHBORHOODS: Neighborhood[] = [
  { id: 'todos', name: 'Todos' },
  { id: 'cerrillos', name: 'Cerrillos' },
  { id: 'la-merced', name: 'La Merced' },
  { id: 'chicoana', name: 'Chicoana' },
  { id: 'el-carril', name: 'El Carril' },
  { id: 'rosario-de-lerma', name: 'Rosario de Lerma' },
  { id: 'moldes', name: 'Moldes' },
  { id: 'guachipas', name: 'Guachipas' },
  { id: 'la-vina', name: 'La Viña' },
  { id: 'campo-quijano', name: 'Campo Quijano' },
  { id: 'san-agustin', name: 'San Agustín' },
];

export const SERVICE_CATEGORIES: ServiceCategory[] = [
  {
    id: 'albanileria',
    name: 'Albañilería y Reformas',
    slug: 'albanileria',
    iconName: 'foundation',
    countText: '24 especialistas activos',
    description: 'Construcción, contrapisos, revoques, colocación de cerámicos y ampliaciones de viviendas.'
  },
  {
    id: 'plomeria',
    name: 'Plomería y Destapes',
    slug: 'plomeria',
    iconName: 'plumbing',
    countText: '18 especialistas activos',
    description: 'Arreglo de fugas, colocación de termotanques, bombas de agua y desobstrucciones cloacales.'
  },
  {
    id: 'electricidad',
    name: 'Electricidad e Instalaciones',
    slug: 'electricidad',
    iconName: 'electrical_services',
    countText: '15 electricistas',
    description: 'Tableros, disyuntores, iluminación LED, cableados nuevos y detección de cortocircuitos.'
  },
  {
    id: 'gasistas',
    name: 'Gasistas Matriculados',
    slug: 'gasistas',
    iconName: 'local_fire_department',
    countText: 'ENARGAS / Gasnor',
    badge: 'Matriculados',
    description: 'Inspecciones técnicas, trámites ante Gasnor, instalación de calefones, estufas y cocinas.'
  },
  {
    id: 'pintura',
    name: 'Pintura e Impermeabilización',
    slug: 'pintura',
    iconName: 'format_paint',
    countText: '12 pintores de obra',
    description: 'Pintura látex interior y exterior, membrana líquida, impermeabilización de techos y texturados.'
  },
  {
    id: 'jardineria',
    name: 'Jardinería y Desmalezado',
    slug: 'jardineria',
    iconName: 'yard',
    countText: '9 cuadrillas locales',
    description: 'Corte de pasto con motoguadaña, poda de árboles frutales, parquizaciones y limpieza de terrenos.'
  },
  {
    id: 'cerrajeria',
    name: 'Cerrajería y Urgencias',
    slug: 'cerrajeria',
    iconName: 'key',
    countText: 'Guardia 24hs',
    badge: '24 Horas',
    description: 'Aperturas de puertas de urgencia, cambio de combinaciones, cerraduras de seguridad.'
  },
  {
    id: 'climatizacion',
    name: 'Aire Acondicionado & Clima',
    slug: 'climatizacion',
    iconName: 'ac_unit',
    countText: 'Instalación y service',
    description: 'Colocación de aires split, carga de gas refrigerante, mantenimiento preventivo y limpieza de filtros.'
  },
  {
    id: 'gastronomia',
    name: 'Comida y Gastronomía',
    slug: 'gastronomia',
    iconName: 'utensils',
    countText: 'Rotiserías, catering y viandas',
    badge: 'Del Valle',
    description: 'Empanadas salteñas al horno de barro, catering para eventos, asadores a domicilio, viandas caseras y repostería artesanal.'
  },
  {
    id: 'automotor',
    name: 'Automotor y Mecánica',
    slug: 'automotor',
    iconName: 'car',
    countText: 'Talleres y auxilio mecánico',
    description: 'Mecánica integral, electricidad automotor, tren delantero, frenos, cambio de aceite y auxilio en ruta 68.'
  },
  {
    id: 'remis',
    name: 'Remis y Traslados',
    slug: 'remis',
    iconName: 'taxi',
    countText: 'Viajes locales y a Salta',
    badge: '24 Horas',
    description: 'Servicio de remis 24hs, traslados a Salta Capital, viajes al Dique Cabra Corral, fletes chicos y encomiendas.'
  },
  {
    id: 'piletas',
    name: 'Limpieza de Piletas',
    slug: 'piletas',
    iconName: 'pool',
    countText: 'Mantenimiento y bombas',
    description: 'Aspirado de fondo, control de cloro y pH, recuperación de agua verde, service de bombas y filtros de arena.'
  },
  {
    id: 'uber',
    name: 'Uber y Chofer Particular',
    slug: 'uber',
    iconName: 'uber',
    countText: 'Viajes inmediatos y coordinados',
    badge: 'En el Valle',
    description: 'Viajes por aplicación, viajes coordinados, traslados al Aeropuerto, Salta Capital y recorridos en todo el Valle de Lerma.'
  },
  {
    id: 'ventas-varias',
    name: 'Ventas Varias',
    slug: 'ventas-varias',
    iconName: 'shopping_bag',
    countText: 'Comercios y productos locales',
    badge: 'Comercio',
    description: 'Artículos para el hogar, calzado, indumentaria, herramientas, bazar, productos regionales y ventas particulares.'
  },
  {
    id: 'otros-servicios',
    name: 'Otros Servicios',
    slug: 'otros-servicios',
    iconName: 'more_horizontal',
    countText: 'Servicios generales y gestoría',
    badge: 'Comunidad',
    description: 'Cuidado de adultos y niños, clases particulares, gestoría y trámites, peluquería a domicilio, informática y reparaciones menores.'
  }
];

export const INITIAL_PROFESSIONALS: Professional[] = [
  {
    id: 'roberto-gomez',
    name: 'Roberto Gómez',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCpq_tkzuBQx2Ou2qFzb63CiAjD0HtMGwGRUGQugoX1X6uxfjdlPdoPz4hZGVk0gpXe4zaZSUO9bDROnwZYEA57LdwmMQLVdKITB7u_fghCDv53bxoRPR_9bn_NgJl2AtDDWKEgqVaKw596ZNsI9NUMxK6Y7tWslswH_JxOfkzy39OSehYmPQQ1JfGZWfqKar0wFElolt5E3pTd5vzDlfAQMGdn0BL3AGV1IASlmRzN2oz5mAkhp9rn',
    trade: 'Albañil y Constructor',
    categoryId: 'albanileria',
    neighborhood: 'Cerrillos',
    rating: 4.9,
    reviewCount: 48,
    verified: true,
    verifiedLabel: 'Verificado',
    availableNow: true,
    emergencyDuty: false,
    quoteWithoutCharge: true,
    isExample: true,
    phone: '+54 387 412-8841',
    whatsappNumber: '5493874128841',
    experienceYears: 18,
    bio: 'Maestro mayor de obras prácticas con más de 18 años edificando en Cerrillos, La Merced y San Agustín. Especialista en losas, contrapisos, colocación fina de porcelanato y ampliaciones de casas familiares. Trabajo serio con cuadrilla propia y referencias comprobables en todo el Valle de Lerma.',
    guaranteeText: 'Garantía vecinal de mano de obra',
    priceTagText: 'Presupuesto sin cargo',
    services: [
      { name: 'Levantado de muros y mampostería tradicional', priceEstimate: 'Desde $12.000 / m2' },
      { name: 'Colocación de cerámicos y porcelanatos', priceEstimate: 'Desde $14.500 / m2' },
      { name: 'Construcción de quinchos y asadores criollos', priceEstimate: 'A convenir con plano' },
      { name: 'Revoques grueso y fino fratasado', priceEstimate: 'Desde $9.500 / m2' }
    ],
    completedJobs: [
      {
        title: 'Ampliación de cocina comedor y galería',
        imageUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=600&q=80',
        neighborhood: 'Cerrillos',
        date: 'Hace 2 semanas',
        comment: 'Se levantaron 35m2 de mampostería con ladrillo cerámico del 18, losa con viguetas pretensadas y contrapiso reforzado para galería.',
        verifiedByApp: true,
        contractNumber: 'ORD-VALLE-2026-004',
        clientName: 'Marcos Vilte'
      },
      {
        title: 'Colocación de porcelanato rústico en patio',
        imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=600&q=80',
        neighborhood: 'La Merced',
        date: 'Hace 1 mes',
        comment: 'Nivelación previa de carpeta y colocación de porcelanato 60x60 antideslizante con junta de 3mm y pastina impermeable.',
        verifiedByApp: true,
        contractNumber: 'ORD-VALLE-2026-005',
        clientName: 'Lucas Pastrana'
      },
      {
        title: 'Asador tradicional con campana de ladrillos',
        imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80',
        neighborhood: 'San Agustín',
        date: 'Hace 2 meses',
        comment: 'Construcción integral de quincho y parrilla con ladrillos refractarios en piso y laterales, tiraje con pulmón antihumo.',
        verifiedByApp: true,
        contractNumber: 'ORD-VALLE-2026-006',
        clientName: 'Estela Morales'
      }
    ],
    reviews: [
      {
        id: 'r1',
        author: 'Marcos Vilte',
        date: '14 de Agosto, 2026',
        rating: 5,
        comment: 'Roberto y sus muchachos hicieron la ampliación del fondo de casa. Muy prolijos, puntuales y cuidaron todos los materiales. Lo recomiendo con los ojos cerrados.',
        neighborhood: 'Cerrillos'
      },
      {
        id: 'r2',
        author: 'Estela Morales',
        date: '28 de Julio, 2026',
        rating: 5,
        comment: 'Excelente albañil. Vino en el día a presupuestar sin cobrar un peso y cumplió exactamente los plazos pactados.',
        neighborhood: 'La Merced'
      }
    ]
  },
  {
    id: 'carlos-mamani',
    name: 'Carlos Mamaní',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA54etxC3UaV4NwIOym4E6WHdqN1rk9m2u8BFT0eWuME9sCPPkAG7k5lTum0iDVdN_5XvxkXF_67kOKLWA-Yeif37K-wjp6FgLvEbImqqmGgCNKIRWfiSzWCpGpgWOrbsIhRV04KzQkkrptByXWvPEm9e36xuMBe3wioaJVD0RcYwCl-tex6wQNgR7ZgJpExVQ__8Jg6H-q8-BRUKon4_qRTTiZ8PlojJZ6Ocdnxg2_XWa4PJnG4LD7',
    trade: 'Electricista Domiciliario',
    categoryId: 'electricidad',
    neighborhood: 'Rosario de Lerma',
    rating: 5.0,
    reviewCount: 32,
    verified: true,
    verifiedLabel: 'Disponible ahora',
    availableNow: true,
    emergencyDuty: true,
    quoteWithoutCharge: true,
    isExample: true,
    matricula: 'MP N° 4192 / COPIPA Salta',
    phone: '+54 387 523-9902',
    whatsappNumber: '5493875239902',
    experienceYears: 12,
    bio: 'Técnico electricista matriculado en Salta. Atención inmediata para urgencias domiciliarias en Rosario de Lerma, Campo Quijano y Cerrillos. Instalación de térmicas, disyuntores diferenciales, puesta a tierra (jabalina con medición de resistencia) y cableados aprobados bajo norma IRAM.',
    guaranteeText: 'Matrícula Provincial COPIPA',
    priceTagText: 'Atención de urgencia hoy',
    services: [
      { name: 'Urgencia por corte de luz o disyuntor caído', priceEstimate: '$15.000 visita diagnóstico' },
      { name: 'Armado y recambio de tablero eléctrico general', priceEstimate: 'Desde $35.000 + materiales' },
      { name: 'Instalación de jabalina con protocolo de medición', priceEstimate: '$28.000' },
      { name: 'Iluminación exterior y reflectores solares/LED', priceEstimate: '$12.000 por boca' }
    ],
    completedJobs: [
      {
        title: 'Modernización de tablero con disyuntor bipolar',
        imageUrl: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&w=600&q=80',
        neighborhood: 'Rosario de Lerma',
        date: 'Ayer'
      },
      {
        title: 'Puesta a tierra reglamentaria en vivienda nueva',
        imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80',
        neighborhood: 'Campo Quijano',
        date: 'Hace 4 días'
      }
    ],
    reviews: [
      {
        id: 'r3',
        author: 'Dario Figueroa',
        date: '1 de Septiembre, 2026',
        rating: 5,
        comment: 'Se nos cortó la luz un domingo a las 20hs por un cortocircuito en el enchufe de la heladera. Carlos vino en 20 minutos con tester y repuestos. Un genio total.',
        neighborhood: 'Rosario de Lerma'
      },
      {
        id: 'r4',
        author: 'Silvia Albarracín',
        date: '20 de Agosto, 2026',
        rating: 5,
        comment: 'Muy responsable y educado. Nos dejó certificado de aptitud eléctrica para el trámite del medidor EDESA.',
        neighborhood: 'Cerrillos'
      }
    ]
  },
  {
    id: 'dona-carmen-guaymas',
    name: 'Doña Carmen Guaymas',
    avatar: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=400&q=80',
    trade: 'Rotisería y Comidas Criollas',
    categoryId: 'gastronomia',
    neighborhood: 'Rosario de Lerma',
    rating: 4.9,
    reviewCount: 46,
    verified: true,
    verifiedLabel: 'Disponible hoy',
    availableNow: true,
    emergencyDuty: false,
    quoteWithoutCharge: true,
    isExample: true,
    phone: '+54 387 493-2190',
    whatsappNumber: '5493874932190',
    experienceYears: 16,
    bio: 'Elaboración artesanal de empanadas salteñas cortadas a cuchillo al horno de barro, locro criollo pulsudo, humitas en chala y catering de comida regional para eventos en Rosario de Lerma.',
    guaranteeText: 'Higiene y sabor tradicional',
    priceTagText: 'Presupuesto y delivery',
    services: [
      { name: 'Empanadas salteñas de carne a cuchillo (docena)', priceEstimate: '$14.000 / docena' },
      { name: 'Locro tradicional salteño en porciones', priceEstimate: '$7.500 por porción' },
      { name: 'Humitas en chala y tamales criollos', priceEstimate: '$12.000 la docena' },
      { name: 'Catering de comidas criollas para eventos', priceEstimate: 'A convenir por cantidad' }
    ],
    completedJobs: [
      {
        title: 'Catering criollo para fiesta familiar',
        imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=600&q=80',
        neighborhood: 'Rosario de Lerma',
        date: 'Hace 3 días',
        comment: 'Servicio de 15 docenas de empanadas y cazuelas de locro caliente para 50 personas.',
        verifiedByApp: true,
        contractNumber: 'ORD-VALLE-2026-009',
        clientName: 'Raúl Maza'
      }
    ],
    reviews: [
      {
        id: 'r-dona-1',
        author: 'Raúl Maza',
        date: 'Ayer',
        rating: 5,
        comment: 'Las mejores empanadas y comida criolla de Rosario de Lerma. Jugosas, masa casera y excelente atención.',
        neighborhood: 'Rosario de Lerma'
      }
    ]
  },
  {
    id: 'mariana-figueroa',
    name: 'Mariana Figueroa',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
    trade: 'Sandwichería, Minutas y Empanadas',
    categoryId: 'gastronomia',
    neighborhood: 'Cerrillos',
    rating: 4.8,
    reviewCount: 38,
    verified: true,
    verifiedLabel: 'Disponible hoy',
    availableNow: true,
    emergencyDuty: false,
    quoteWithoutCharge: true,
    isExample: true,
    phone: '+54 387 512-8877',
    whatsappNumber: '5493875128877',
    experienceYears: 10,
    bio: 'Sandwiches especiales de milanesa, lomitos completos, pizzas a la piedra y viandas de comida casera en Cerrillos.',
    guaranteeText: 'Calidad y rapidez',
    priceTagText: 'Delivery en Cerrillos',
    services: [
      { name: 'Sandwich de milanesa completo con papas', priceEstimate: '$8.500' },
      { name: 'Lomito gourmet en pan casero', priceEstimate: '$9.800' },
      { name: 'Pizzas artesanales y empanadas', priceEstimate: 'Desde $11.000' }
    ],
    completedJobs: [],
    reviews: [
      {
        id: 'r-mar-1',
        author: 'Joaquín Santos',
        date: 'Hace 2 días',
        rating: 5,
        comment: 'Excelente comida y minutas en Cerrillos. Llegó caliente y super abundante.',
        neighborhood: 'Cerrillos'
      }
    ]
  }
];

/**
 * Normalizes text removing accents, hyphens, underscores and converting to lowercase
 */
export const normalizeFilterText = (str: string | undefined | null): string => {
  return (str || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[-_]/g, ' ')
    .trim();
};

/**
 * Checks if a worker's neighborhood strictly matches the selected department/locality
 */
export const isWorkerInNeighborhood = (
  workerNeighborhood: string | undefined | null,
  selectedNeighborhood: string
): boolean => {
  if (!selectedNeighborhood || selectedNeighborhood === 'todos') {
    return true;
  }
  if (!workerNeighborhood || !workerNeighborhood.trim()) {
    return false;
  }

  const targetObj = NEIGHBORHOODS.find(n => 
    n.id === selectedNeighborhood ||
    normalizeFilterText(n.id) === normalizeFilterText(selectedNeighborhood) ||
    normalizeFilterText(n.name) === normalizeFilterText(selectedNeighborhood)
  );

  const targetName = targetObj ? normalizeFilterText(targetObj.name) : normalizeFilterText(selectedNeighborhood);
  const targetId = targetObj ? normalizeFilterText(targetObj.id) : normalizeFilterText(selectedNeighborhood);
  const workerLoc = normalizeFilterText(workerNeighborhood);

  if (!workerLoc) {
    return false;
  }

  // Exact match or sub-neighborhood match (e.g. "Barrio San Jorge, Rosario de Lerma")
  return (
    workerLoc === targetName ||
    workerLoc === targetId ||
    workerLoc.includes(targetName) ||
    workerLoc.includes(targetId)
  );
};

/**
 * Checks if a worker profile matches a text search query across name, trade, category, services and bio
 */
export const isWorkerMatchingSearch = (worker: Professional, query: string): boolean => {
  if (!query || !query.trim()) {
    return true;
  }

  const qNorm = normalizeFilterText(query);
  const terms = qNorm.split(/\s+/).filter(Boolean);

  return terms.every(term => {
    const matchesName = normalizeFilterText(worker.name).includes(term);
    const matchesTrade = normalizeFilterText(worker.trade).includes(term);
    const matchesBarrio = normalizeFilterText(worker.neighborhood).includes(term);
    const matchesBio = normalizeFilterText(worker.bio || '').includes(term);
    const matchesServices = (worker.services || []).some(s => 
      normalizeFilterText(s.name).includes(term) || 
      normalizeFilterText(s.description || '').includes(term)
    );
    const catObj = SERVICE_CATEGORIES.find(c => c.id === worker.categoryId);
    const matchesCategory = catObj ? (
      normalizeFilterText(catObj.name).includes(term) || 
      normalizeFilterText(catObj.slug).includes(term) || 
      normalizeFilterText(catObj.description || '').includes(term)
    ) : false;

    return matchesName || matchesTrade || matchesBarrio || matchesBio || matchesServices || matchesCategory;
  });
};

export const INITIAL_REQUESTS: ServiceRequest[] = [
  {
    id: 'req-1',
    title: 'Reparación de cañería y grifería de cocina',
    trade: 'Plomería y Gasista',
    neighborhood: 'El Carril',
    description: 'Tengo una filtración debajo de la bacha de la cocina que moja el bajo mesada. Necesito cambiar flexibles y ajustar la grifería monocomando.',
    createdAt: 'Hoy, hace 2 horas',
    status: 'contratado',
    contractNumber: 'ORD-VALLE-2026-01',
    quotedBy: 'Juan Cruz Valdiviezo',
    assignedWorkerId: 'juan-cruz-valdiviezo',
    quotedByAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDKQk3laMi0s9ihNn6mEIo0yowe-Gwn_uy1vxJzhe5pq9Mh83UMJrbo5gbNKmkmsIO_jUGbt9CJo26i4tg3PVUILAuifzwdawmDaQUEiBE1p6yxcJKRlKROFHnt8keyXVI-cSP4mqZNpEHRutZbkOm-uD0od9O2aaNDBpRhivpVqN8Tr2kXkW4LSV34obnmV9v24xvNaGrV-ibVbyZlbxxptRdO0yBorC-URLwOW9EbHH8KBYaE1k-l',
    quotedByTrade: 'Plomero & Gasista Matriculado',
    quoteAmount: 18000,
    phoneContact: '+54 387 499-1304',
    clientName: 'Familia Morales'
  },
  {
    id: 'req-2',
    title: 'Instalación de disyuntor y térmicas nuevas',
    trade: 'Electricidad e Instalaciones',
    neighborhood: 'Cerrillos',
    description: 'Quiero cambiar los tapones viejos por térmicas Schneider nuevas y poner un disyuntor diferencial para mayor seguridad.',
    createdAt: 'Ayer a las 17:30',
    status: 'cotizado',
    contractNumber: 'ORD-VALLE-2026-02',
    quotedBy: 'Carlos Mamaní',
    assignedWorkerId: 'carlos-mamani',
    quotedByAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA54etxC3UaV4NwIOym4E6WHdqN1rk9m2u8BFT0eWuME9sCPPkAG7k5lTum0iDVdN_5XvxkXF_67kOKLWA-Yeif37K-wjp6FgLvEbImqqmGgCNKIRWfiSzWCpGpgWOrbsIhRV04KzQkkrptByXWvPEm9e36xuMBe3wioaJVD0RcYwCl-tex6wQNgR7ZgJpExVQ__8Jg6H-q8-BRUKon4_qRTTiZ8PlojJZ6Ocdnxg2_XWa4PJnG4LD7',
    quotedByTrade: 'Electricista Domiciliario',
    quoteAmount: 25000,
    phoneContact: '+54 387 523-9902',
    clientName: 'Juan Martín López'
  },
  {
    id: 'req-3',
    title: 'Construcción de asador y quincho familiar',
    trade: 'Albañilería y Construcción',
    neighborhood: 'Cerrillos',
    description: 'Construcción de parrillero de 2.20m con ladrillos refractarios, mesada auxiliar y losa.',
    createdAt: 'Hace 3 días',
    status: 'completado',
    contractNumber: 'ORD-VALLE-2026-03',
    quotedBy: 'Roberto Gómez',
    assignedWorkerId: 'roberto-gomez',
    quotedByAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    quotedByTrade: 'Maestro Mayor de Obras & Albañil',
    quoteAmount: 140000,
    phoneContact: '+54 387 499-8812',
    clientName: 'Estela Morales',
    completedJobPhoto: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80',
    completedJobComment: 'Construcción integral de quincho y parrilla con ladrillos refractarios en piso y laterales, tiraje con pulmón antihumo.'
  },
  {
    id: 'req-4',
    title: 'Viaje y traslado familiar de Cerrillos a Chicoana',
    trade: 'Uber, Traslados y Fletes',
    neighborhood: 'Cerrillos',
    description: 'Necesitamos traslado ida y vuelta para 4 personas este domingo a un almuerzo familiar en Chicoana. Con espera de 3 horas.',
    createdAt: 'Hoy, hace 30 minutos',
    status: 'en_espera',
    clientName: 'Gonzalo Albornoz',
    phoneContact: '+54 387 544-3211'
  },
  {
    id: 'req-5',
    title: 'Catering de empanadas salteñas para 25 personas',
    trade: 'Gastronomía y Comidas Criollas',
    neighborhood: 'La Merced',
    description: 'Necesitamos 8 docenas de empanadas de carne cortadas a cuchillo y 2 de queso para cumpleaños este sábado por la noche.',
    createdAt: 'Hoy, hace 1 hora',
    status: 'en_espera',
    clientName: 'Mariana Figueroa',
    phoneContact: '+54 387 512-8877'
  },
  {
    id: 'req-6',
    title: 'Cambio de pastillas de freno y afinación de motor',
    trade: 'Mecánica y Auxilio Móvil',
    neighborhood: 'El Carril',
    description: 'Renault Kangoo hace ruido al frenar y tironea en baja. Necesito revisión a domicilio o en taller de la zona.',
    createdAt: 'Ayer',
    status: 'en_espera',
    clientName: 'Héctor Wayar',
    phoneContact: '+54 387 488-9900'
  }
];

export const INITIAL_USER_PROFILE: UserProfile = {
  name: 'Juan Martín López',
  avatar: USER_AVATAR_URL,
  neighborhood: 'Cerrillos',
  city: 'Valle de Lerma, Salta',
  email: 'jmlsalta@gmail.com',
  phone: '+54 387 455-8910',
  favorites: ['roberto-gomez', 'carlos-mamani']
};

export const EMERGENCY_NUMBERS = [
  { name: 'Hospital Santa Teresita (Cerrillos)', phone: '0387 499-9022', icon: 'hospital' },
  { name: 'Hospital Dr. Rafael Villagrán (Chicoana)', phone: '0387 490-7023', icon: 'hospital' },
  { name: 'Bomberos Voluntarios del Valle', phone: '0387 499-9100', icon: 'fire_extinguisher' },
  { name: 'Policía del Valle de Lerma (911)', phone: '911', icon: 'shield' },
  { name: 'Gasnor Emergencias de Gas 24hs', phone: '0800 555-8800', icon: 'flame' },
  { name: 'EDESA Guardia de Energía Eléctrica', phone: '0800 777-33372', icon: 'zap' }
];

export const AD_IMAGE_PRESETS = [
  {
    name: 'Ferretería & Bulonería',
    url: 'https://images.unsplash.com/photo-1581783898377-1c85bf937427?auto=format&fit=crop&q=80&w=1000',
    category: 'Materiales y Herramientas'
  },
  {
    name: 'Gastronomía & Sandwiches',
    url: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&q=80&w=1000',
    category: 'Comidas y Minutas'
  },
  {
    name: 'Pinturas & Revestimientos',
    url: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&q=80&w=1000',
    category: 'Pinturería'
  },
  {
    name: 'Supermercado & Carnicería',
    url: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&q=80&w=1000',
    category: 'Alimentos y Comercio'
  },
  {
    name: 'Climatización & Electro',
    url: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=1000',
    category: 'Aire & Hogar'
  }
];

export const DAYS_OF_WEEK = [
  { id: 1, label: 'Lunes', short: 'Lun' },
  { id: 2, label: 'Martes', short: 'Mar' },
  { id: 3, label: 'Miércoles', short: 'Mié' },
  { id: 4, label: 'Jueves', short: 'Jue' },
  { id: 5, label: 'Viernes', short: 'Vie' },
  { id: 6, label: 'Sábado', short: 'Sáb' },
  { id: 0, label: 'Domingo', short: 'Dom' },
];

export const formatScheduledDays = (days?: number[]): string => {
  if (!days || days.length === 0 || days.length === 7) {
    return 'Todos los días';
  }
  if (days.length === 2 && days.includes(1) && days.includes(3)) {
    return 'Lunes y Miércoles';
  }
  if (days.length === 2 && days.includes(5) && days.includes(6)) {
    return 'Viernes y Sábados';
  }
  if (days.length === 5 && [1, 2, 3, 4, 5].every(d => days.includes(d))) {
    return 'Lunes a Viernes';
  }
  if (days.length === 2 && days.includes(6) && days.includes(0)) {
    return 'Fines de semana (Sáb y Dom)';
  }

  // Ordered display Lun -> Dom
  const sorted = [...days].sort((a, b) => {
    const orderA = a === 0 ? 7 : a;
    const orderB = b === 0 ? 7 : b;
    return orderA - orderB;
  });

  return sorted
    .map(d => DAYS_OF_WEEK.find(item => item.id === d)?.short || '')
    .filter(Boolean)
    .join(', ');
};

export const isAdScheduledForDay = (ad: AppAdvertisement, dayIndex: number): boolean => {
  if (!ad.enabled) return false;
  if (!ad.daysOfWeek || ad.daysOfWeek.length === 0) return true;
  return ad.daysOfWeek.includes(dayIndex);
};

export const DEFAULT_ADVERTISEMENTS: AppAdvertisement[] = [
  {
    id: 'ad-ferreteria-turco',
    enabled: true,
    title: 'Ferretería y Bulonería El Turco',
    subtitle: 'Cerrillos Centro • Plomería, Electricidad y Pinturas',
    badgeText: 'LUNES Y MIÉRCOLES',
    description: '15% de descuento en herramientas y accesorios para profesionales del Valle de Lerma. Stock completo en caños, cables, fijaciones y herramientas eléctricas.',
    imageUrl: 'https://images.unsplash.com/photo-1581783898377-1c85bf937427?auto=format&fit=crop&q=80&w=1000',
    displayDurationSeconds: 3,
    buttonText: 'Pedir Presupuesto por WhatsApp',
    targetType: 'whatsapp',
    targetWhatsAppNumber: '3875286914',
    targetWhatsAppMessage: 'Hola Ferretería El Turco, vi su publicidad en Oficios Cerrillos y quiero consultar por herramientas y materiales.',
    daysOfWeek: [1, 3], // Lunes y Miércoles
    updatedAt: new Date().toISOString()
  },
  {
    id: 'ad-sandwicheria-tentacion',
    enabled: true,
    title: 'Sandwichería y Minutas Tentación',
    subtitle: 'Cerrillos • Lomitos, Milanesas, Empanadas y Papas',
    badgeText: 'VIERNES Y SÁBADOS',
    description: '¡Los mejores lomitos completos y hamburguesas artesanales de Cerrillos! Delivery nocturno veloz y atención para toda la familia en el fin de semana.',
    imageUrl: 'https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&q=80&w=1000',
    displayDurationSeconds: 3,
    buttonText: 'Hacer Pedido por WhatsApp',
    targetType: 'whatsapp',
    targetWhatsAppNumber: '3875286914',
    targetWhatsAppMessage: 'Hola Sandwichería Tentación, vi la promo de fin de semana en Oficios Cerrillos y me gustaría hacer un pedido.',
    daysOfWeek: [5, 6], // Viernes y Sábados
    updatedAt: new Date().toISOString()
  },
  {
    id: 'ad-corralon-el-valle',
    enabled: true,
    title: 'Corralón y Cerámicos El Valle',
    subtitle: 'La Merced y Cerrillos • Áridos, Cemento y Ladrillos',
    badgeText: 'MARTES Y JUEVES',
    description: 'Materiales gruesos para construcción y reformas con flete directo a obra en Cerrillos, La Merced y El Carril. Cotización sin cargo.',
    imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&q=80&w=1000',
    displayDurationSeconds: 3,
    buttonText: 'Cotizar Materiales por WhatsApp',
    targetType: 'whatsapp',
    targetWhatsAppNumber: '3875286914',
    targetWhatsAppMessage: 'Hola Corralón El Valle, vi la publicidad en la aplicación de Oficios Cerrillos.',
    daysOfWeek: [2, 4], // Martes y Jueves
    updatedAt: new Date().toISOString()
  }
];

export const DEFAULT_ADVERTISEMENT: AppAdvertisement = DEFAULT_ADVERTISEMENTS[0];

export const INITIAL_ACCOUNTS: ProAccount[] = [
  { proId: 'roberto-gomez', username: 'roberto', password: '123', createdAt: new Date().toISOString(), trialDaysTotal: 30 },
  { proId: 'carlos-mamani', username: 'carlos', password: '123', createdAt: new Date().toISOString(), trialDaysTotal: 30 }
];
