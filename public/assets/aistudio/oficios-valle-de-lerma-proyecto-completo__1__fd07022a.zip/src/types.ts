export interface ServiceItem {
  name: string;
  priceEstimate?: string;
  description?: string;
}

export interface CompletedJob {
  id?: string;
  serviceRequestId?: string;
  contractNumber?: string;
  clientName?: string;
  title: string;
  imageUrl?: string;
  photoUrl?: string;
  neighborhood: string;
  date?: string;
  comment?: string;
  verifiedByApp?: boolean;
}

export interface Review {
  id: string;
  author: string;
  date: string;
  rating: number;
  comment: string;
  neighborhood: string;
}

export interface Professional {
  id: string;
  name: string;
  avatar: string;
  trade: string;
  categoryId: string;
  neighborhood: string;
  rating: number;
  reviewCount: number;
  verified: boolean;
  verifiedLabel?: string;
  availableNow: boolean;
  emergencyDuty: boolean;
  quoteWithoutCharge: boolean;
  matricula?: string;
  certificatePhotoUrl?: string;
  dniNumber?: string;
  dniPhotoUrl?: string;
  approvalStatus?: 'aprobado' | 'pendiente' | 'rechazado';
  submissionDate?: string;
  rejectionReason?: string;
  phone: string;
  whatsappNumber: string;
  experienceYears: number;
  bio: string;
  guaranteeText: string;
  priceTagText: string;
  username?: string;
  password?: string;
  trialStartDate?: string;
  trialEndDate?: string;
  trialDaysTotal?: number;
  trialActive?: boolean;
  subscriptionPlan?: 'prueba_gratuita' | 'abono_mensual' | 'abono_anual';
  subscriptionStatus?: 'activa' | 'caducada';
  subscriptionEndDate?: string;
  isTrialExpired?: boolean;
  isExample?: boolean;
  services: ServiceItem[];
  completedJobs: CompletedJob[];
  reviews: Review[];
}

export interface ProAccount {
  id?: string;
  username: string;
  password?: string;
  professionalId?: string;
  proId?: string;
  registeredAt?: string;
  createdAt?: string;
  trialDaysTotal?: number;
  trialEndDate?: string;
  isActive?: boolean;
}

export interface ServiceCategory {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  countText: string;
  description?: string;
  badge?: string;
}

export interface Neighborhood {
  id: string;
  name: string;
}

export interface ServiceRequest {
  id: string;
  title: string;
  trade: string;
  neighborhood: string;
  description: string;
  createdAt: string;
  status: 'cotizado' | 'en_espera' | 'contratado' | 'completado';
  quotedBy?: string;
  quotedByAvatar?: string;
  quotedByTrade?: string;
  quoteAmount?: number;
  phoneContact?: string;
  assignedWorkerId?: string;
  contractNumber?: string;
  clientName?: string;
  completedJobPhoto?: string;
  completedJobComment?: string;
}

export interface UserProfile {
  name: string;
  avatar: string;
  neighborhood: string;
  city: string;
  email: string;
  phone: string;
  favorites: string[];
}

export interface AppAdvertisement {
  id: string;
  enabled: boolean;
  title: string;
  subtitle?: string;
  badgeText?: string;
  description: string;
  imageUrl?: string;
  displayDurationSeconds: number; // e.g. 3
  buttonText?: string;
  targetType: 'whatsapp' | 'url' | 'none';
  targetUrl?: string;
  targetWhatsAppNumber?: string;
  targetWhatsAppMessage?: string;
  daysOfWeek?: number[]; // [0, 1, 2, 3, 4, 5, 6] (0 = Domingo, 1 = Lunes, ..., 6 = Sábado). Vacío = Todos los días
  updatedAt?: string;
}

export interface AppAnalytics {
  id?: string;
  totalClientVisits: number; // Conteo de veces que vecinos/clientes usaron la app
  uniqueClientsCount: number; // Conteo de clientes únicos aproximados (dispositivos distintos)
  totalWhatsAppContacts: number; // Vecinos que contactaron a prestadores vía WhatsApp
  totalRequestsCreated: number; // Solicitudes o pedidos de presupuestos enviados por vecinos
  lastClientVisitAt?: string; // Fecha y hora del último cliente que ingresó
  firstRecordedAt?: string;
}
