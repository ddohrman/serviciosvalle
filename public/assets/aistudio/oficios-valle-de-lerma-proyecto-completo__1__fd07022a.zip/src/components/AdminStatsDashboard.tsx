import React, { useState } from 'react';
import { 
  Users, 
  UserCheck, 
  Sparkles, 
  Clock, 
  AlertTriangle, 
  MessageCircle, 
  Calendar, 
  TrendingUp, 
  ArrowRight, 
  CheckCircle2, 
  Copy, 
  Check, 
  Smartphone,
  ShieldCheck,
  Zap,
  BarChart2
} from 'lucide-react';
import { AppAnalytics, Professional } from '../types';

interface AdminStatsDashboardProps {
  analytics: AppAnalytics;
  professionals: Professional[];
  onSelectFilter: (filter: 'todos' | 'prueba_activa' | 'prueba_caducada' | 'continuando_uso' | 'pendiente') => void;
  onSwitchToPrestadores: () => void;
}

export const AdminStatsDashboard: React.FC<AdminStatsDashboardProps> = ({
  analytics,
  professionals,
  onSelectFilter,
  onSwitchToPrestadores
}) => {
  const [copiedReport, setCopiedReport] = useState(false);

  // Prestadores calculations
  const totalPros = professionals.length;
  
  // Activos en prueba gratuita (dentro de los 30 días, no caducados y sin abono pago)
  const trialActivePros = professionals.filter(p => {
    const isExpired = p.isTrialExpired || p.subscriptionStatus === 'caducada' || p.trialActive === false;
    const isPaid = (p.subscriptionPlan === 'abono_mensual' || p.subscriptionPlan === 'abono_anual') && p.subscriptionStatus === 'activa';
    return !isExpired && !isPaid;
  });

  // Prestadores con prueba gratuita caducada / vencida
  const trialExpiredPros = professionals.filter(p => {
    const isExpired = p.isTrialExpired || p.subscriptionStatus === 'caducada' || p.trialActive === false;
    const isPaid = (p.subscriptionPlan === 'abono_mensual' || p.subscriptionPlan === 'abono_anual') && p.subscriptionStatus === 'activa';
    return isExpired && !isPaid;
  });

  // Prestadores que continúan su uso con abono activo
  const continuingUsePros = professionals.filter(p => {
    return (p.subscriptionPlan === 'abono_mensual' || p.subscriptionPlan === 'abono_anual') && p.subscriptionStatus === 'activa';
  });

  const abonoMensualPros = professionals.filter(p => p.subscriptionPlan === 'abono_mensual' && p.subscriptionStatus === 'activa');
  const abonoAnualPros = professionals.filter(p => p.subscriptionPlan === 'abono_anual' && p.subscriptionStatus === 'activa');

  // Pendientes de revisión por el admin
  const pendingPros = professionals.filter(p => p.approvalStatus === 'pendiente');
  const approvedPros = professionals.filter(p => !p.approvalStatus || p.approvalStatus === 'aprobado');

  // Percentage calculations
  const totalTrials = trialActivePros.length + trialExpiredPros.length;
  const retentionPercent = totalPros > 0 ? Math.round((continuingUsePros.length / totalPros) * 100) : 0;
  const activeTrialPercent = totalTrials > 0 ? Math.round((trialActivePros.length / totalTrials) * 100) : 0;

  // Format last visit date
  const formatLastVisit = (dateStr?: string) => {
    if (!dateStr) return 'Reciente';
    try {
      const d = new Date(dateStr);
      return d.toLocaleString('es-AR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateStr;
    }
  };

  const handleCopyReport = () => {
    const reportText = `📊 *REPORTE ESTADÍSTICO - OFICIOS Y SERVICIOS VALLE DE LERMA*
Fecha: ${new Date().toLocaleDateString('es-AR')} ${new Date().toLocaleTimeString('es-AR')}
Administradores: Jorge Lopez (Dev) y Daniel Dohrman (Dev)

👥 *CLIENTES / VECINOS*
• Clientes únicos que usaron la app: ${analytics.uniqueClientsCount}
• Total de aperturas/visitas: ${analytics.totalClientVisits}
• Contactos directos por WhatsApp: ${analytics.totalWhatsAppContacts}
• Solicitudes de servicio recibidas: ${analytics.totalRequestsCreated}
• Última visita registrada: ${formatLastVisit(analytics.lastClientVisitAt)}

👷 *PRESTADORES DE OFICIOS (Total: ${totalPros})*
1. *En Prueba Gratuita (30 días)*: ${totalTrials} prestadores
   - Activos en período de prueba: ${trialActivePros.length} (${activeTrialPercent}%)
   - Pruebas caducadas / a contactar: ${trialExpiredPros.length}
2. *Continuando su uso (Abonos activos)*: ${continuingUsePros.length} (${retentionPercent}%)
   - Con Abono Mensual: ${abonoMensualPros.length}
   - Con Abono Anual: ${abonoAnualPros.length}
3. *Estado de Aprobación*:
   - Pendientes de aprobación: ${pendingPros.length}
   - Aprobados y visibles: ${approvedPros.length}`;

    navigator.clipboard.writeText(reportText).then(() => {
      setCopiedReport(true);
      setTimeout(() => setCopiedReport(false), 2500);
    });
  };

  const handleFilterClick = (filter: 'todos' | 'prueba_activa' | 'prueba_caducada' | 'continuando_uso' | 'pendiente') => {
    onSelectFilter(filter);
    onSwitchToPrestadores();
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Header Banner con botón para copiar reporte */}
      <div className="bg-gradient-to-r from-[#001428] via-[#09223a] to-[#122e4d] text-white p-4 sm:p-5 rounded-2xl border border-[#ffdbcb]/20 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-[#9e4300] text-white">
              <BarChart2 className="w-5 h-5" />
            </span>
            <h3 className="font-black text-base text-white">Panel Estadístico General</h3>
          </div>
          <p className="text-xs text-[#d3e4fe]">
            Métricas en tiempo real de clientes que usaron la app y estado de prestadores registrados.
          </p>
        </div>

        <button
          type="button"
          onClick={handleCopyReport}
          className="self-start sm:self-auto px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 text-white text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-xs shrink-0"
          title="Copiar resumen para WhatsApp o notas"
        >
          {copiedReport ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-300">¡Copiado al portapapeles!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-amber-300" />
              <span>Copiar Reporte Resumido</span>
            </>
          )}
        </button>
      </div>

      {/* SECCIÓN 1: CLIENTES QUE USARON LA APP */}
      <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#f1f5f9] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-black text-[#001428]">Clientes que usaron la App</h4>
              <p className="text-[11px] text-[#5a5f67]">Vecinos de Cerrillos y Valle de Lerma conectados</p>
            </div>
          </div>
          <span className="text-[11px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-full">
            Vecinos (Uso Libre)
          </span>
        </div>

        {/* Tarjetas KPI de Clientes */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {/* Clientes Únicos */}
          <div className="p-3.5 rounded-xl bg-gradient-to-br from-[#eff4ff] to-[#e0edff] border border-blue-200/80 space-y-1">
            <div className="flex items-center justify-between text-blue-900">
              <span className="text-[11px] font-bold">Clientes Únicos</span>
              <Smartphone className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-2xl font-black text-[#001428]">{analytics.uniqueClientsCount}</p>
            <p className="text-[10px] text-[#43474d]">Dispositivos vecinos distintos</p>
          </div>

          {/* Total Visitas / Usos */}
          <div className="p-3.5 rounded-xl bg-[#f8fafc] border border-slate-200 space-y-1">
            <div className="flex items-center justify-between text-slate-800">
              <span className="text-[11px] font-bold">Aperturas / Usos</span>
              <TrendingUp className="w-4 h-4 text-slate-600" />
            </div>
            <p className="text-2xl font-black text-[#001428]">{analytics.totalClientVisits}</p>
            <p className="text-[10px] text-[#43474d]">Veces que abrieron la app</p>
          </div>

          {/* Contactos por WhatsApp */}
          <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1">
            <div className="flex items-center justify-between text-emerald-900">
              <span className="text-[11px] font-bold">Contactos WhatsApp</span>
              <MessageCircle className="w-4 h-4 text-emerald-600" />
            </div>
            <p className="text-2xl font-black text-emerald-950">{analytics.totalWhatsAppContacts}</p>
            <p className="text-[10px] text-emerald-800">Clics a prestadores</p>
          </div>

          {/* Solicitudes de servicio */}
          <div className="p-3.5 rounded-xl bg-orange-50 border border-orange-200 space-y-1">
            <div className="flex items-center justify-between text-[#9e4300]">
              <span className="text-[11px] font-bold">Presupuestos</span>
              <Zap className="w-4 h-4 text-[#9e4300]" />
            </div>
            <p className="text-2xl font-black text-[#783100]">{analytics.totalRequestsCreated}</p>
            <p className="text-[10px] text-[#9e4300]/80">Pedidos de vecinos</p>
          </div>
        </div>

        {/* Última actividad registrada */}
        <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#f8f9fc] border border-[#e2e8f0] text-xs text-[#5a5f67]">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-blue-600" />
            <span>Último uso registrado de un cliente:</span>
          </div>
          <span className="font-bold text-[#001428]">{formatLastVisit(analytics.lastClientVisitAt)}</span>
        </div>
      </div>

      {/* SECCIÓN 2: PRESTADORES QUE SE REGISTRARON EN LA APP */}
      <div className="bg-white p-5 rounded-2xl border border-[#e2e8f0] shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-[#f1f5f9] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#ffdbcb] text-[#783100] flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-black text-[#001428]">Prestadores Registrados</h4>
              <p className="text-[11px] text-[#5a5f67]">
                Desglose total, período de prueba y continuidad de uso
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => handleFilterClick('todos')}
            className="text-[11px] font-bold text-[#9e4300] hover:text-[#783100] flex items-center gap-1 cursor-pointer"
          >
            <span>Ver listado ({totalPros})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Tarjeta Destacada: TOTAL PRESTADORES */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-[#001428] to-[#0f2942] text-white flex items-center justify-between">
          <div className="space-y-0.5">
            <p className="text-xs text-[#d3e4fe] font-semibold">Total de Prestadores Registrados en la App</p>
            <p className="text-3xl font-black text-white">{totalPros}</p>
            <p className="text-[11px] text-amber-300">
              {approvedPros.length} aprobados y visibles • {pendingPros.length} pendientes
            </p>
          </div>
          <div className="flex flex-col items-end gap-1.5">
            <span className="px-3 py-1 bg-white/15 rounded-full text-xs font-bold text-white border border-white/20">
              {continuingUsePros.length} Continuando Uso
            </span>
            <span className="text-[11px] text-emerald-300 font-bold">
              {retentionPercent}% Continuidad
            </span>
          </div>
        </div>

        {/* Diferenciación en 2 Bloques Principales: Prueba Gratuita vs Continuando su Uso */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* BLOQUE A: EN PRUEBA GRATUITA (30 DÍAS) */}
          <div className="p-4.5 rounded-2xl bg-[#fffbf7] border border-[#fed7aa] space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-500 animate-pulse"></span>
                <h5 className="font-black text-sm text-[#783100]">En Prueba Gratuita (30 días)</h5>
              </div>
              <span className="text-xs font-black bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full border border-amber-300">
                {totalTrials} prestadores
              </span>
            </div>

            <p className="text-[11px] text-[#783100]/80">
              Registrados con beneficio de 30 días gratis para probar la plataforma en el Valle de Lerma.
            </p>

            {/* Desglose: Activos vs Caducados */}
            <div className="space-y-2.5 pt-1">
              {/* Prueba Activa */}
              <div 
                onClick={() => handleFilterClick('prueba_activa')}
                className="p-3 rounded-xl bg-white border border-emerald-200 hover:border-emerald-400 hover:bg-emerald-50/40 transition-all cursor-pointer flex items-center justify-between"
                title="Hacé clic para ver solo estos prestadores"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-emerald-950">Prueba Activa Vigente</p>
                    <p className="text-[10px] text-emerald-700">En período dentro de los 30 días</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-emerald-900">{trialActivePros.length}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-emerald-700" />
                </div>
              </div>

              {/* Prueba Caducada */}
              <div 
                onClick={() => handleFilterClick('prueba_caducada')}
                className="p-3 rounded-xl bg-white border border-red-200 hover:border-red-400 hover:bg-red-50/40 transition-all cursor-pointer flex items-center justify-between"
                title="Hacé clic para ver los prestadores con prueba caducada a contactar"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-red-100 text-red-800 flex items-center justify-center">
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-red-950">Prueba Caducada / Vencida</p>
                    <p className="text-[10px] text-red-700">Cumplieron los 30 días (Pendientes de abono)</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-red-900">{trialExpiredPros.length}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-red-700" />
                </div>
              </div>
            </div>

            {/* Barra de progreso de la prueba */}
            <div className="pt-1 space-y-1">
              <div className="flex justify-between text-[10px] font-bold text-[#783100]">
                <span>Vigentes: {trialActivePros.length}</span>
                <span>Caducados: {trialExpiredPros.length}</span>
              </div>
              <div className="w-full bg-red-100 h-2 rounded-full overflow-hidden flex">
                <div 
                  className="bg-emerald-500 h-full transition-all duration-500" 
                  style={{ width: `${activeTrialPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* BLOQUE B: LOS QUE CONTINÚAN SU USO (ABONO / PAGO) */}
          <div className="p-4.5 rounded-2xl bg-[#f0f9ff] border border-[#bae6fd] space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-blue-600"></span>
                <h5 className="font-black text-sm text-[#0c4a6e]">Continuando su Uso (Abonos)</h5>
              </div>
              <span className="text-xs font-black bg-blue-100 text-blue-900 px-2 py-0.5 rounded-full border border-blue-300">
                {continuingUsePros.length} prestadores
              </span>
            </div>

            <p className="text-[11px] text-[#0c4a6e]/80">
              Prestadores que superaron la prueba y renovaron su suscripción comercial activa en la app.
            </p>

            {/* Desglose: Abono Mensual vs Anual */}
            <div className="space-y-2.5 pt-1">
              {/* Abono Mensual */}
              <div 
                onClick={() => handleFilterClick('continuando_uso')}
                className="p-3 rounded-xl bg-white border border-blue-200 hover:border-blue-400 hover:bg-blue-50/40 transition-all cursor-pointer flex items-center justify-between"
                title="Hacé clic para ver prestadores con abono mensual"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center">
                    <Check className="w-4 h-4 text-blue-700" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-blue-950">Abono Mensual Activo</p>
                    <p className="text-[10px] text-blue-700">Renovación mes a mes</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-blue-900">{abonoMensualPros.length}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-blue-700" />
                </div>
              </div>

              {/* Abono Anual */}
              <div 
                onClick={() => handleFilterClick('continuando_uso')}
                className="p-3 rounded-xl bg-white border border-purple-200 hover:border-purple-400 hover:bg-purple-50/40 transition-all cursor-pointer flex items-center justify-between"
                title="Hacé clic para ver prestadores con abono anual"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-purple-700" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-purple-950">Abono Anual Destacado</p>
                    <p className="text-[10px] text-purple-700">Suscripción anual completa</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-purple-900">{abonoAnualPros.length}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-purple-700" />
                </div>
              </div>
            </div>

            {/* Tasa de fidelización comercial */}
            <div className="p-2.5 rounded-xl bg-white/80 border border-blue-200 flex items-center justify-between text-xs">
              <span className="text-[#0c4a6e] font-semibold">Tasa de fidelización comercial:</span>
              <span className="font-black text-blue-900 bg-blue-100 px-2 py-0.5 rounded-md">
                {retentionPercent}% del padrón
              </span>
            </div>
          </div>
        </div>

        {/* Botones de acceso rápido para administrar los prestadores según su estado */}
        <div className="pt-2 flex flex-wrap gap-2 items-center justify-between">
          <span className="text-xs text-[#5a5f67] font-semibold">
            Filtrar listado de prestadores por:
          </span>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => handleFilterClick('prueba_activa')}
              className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-100 hover:bg-emerald-200 text-emerald-900 transition-colors cursor-pointer"
            >
              Prueba Activa ({trialActivePros.length})
            </button>
            <button
              type="button"
              onClick={() => handleFilterClick('prueba_caducada')}
              className="px-2.5 py-1 rounded-lg text-xs font-bold bg-red-100 hover:bg-red-200 text-red-900 transition-colors cursor-pointer"
            >
              Prueba Caducada ({trialExpiredPros.length})
            </button>
            <button
              type="button"
              onClick={() => handleFilterClick('continuando_uso')}
              className="px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-100 hover:bg-blue-200 text-blue-900 transition-colors cursor-pointer"
            >
              Continuando Uso ({continuingUsePros.length})
            </button>
            <button
              type="button"
              onClick={() => handleFilterClick('pendiente')}
              className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-100 hover:bg-amber-200 text-amber-900 transition-colors cursor-pointer"
            >
              Pendientes ({pendingPros.length})
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
